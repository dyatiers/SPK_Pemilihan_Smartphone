package com.dayatrzki.spkpemilihansmartphone

import android.app.ProgressDialog
import android.content.Intent
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_register.*
import org.json.JSONException
import org.json.JSONObject
import java.util.HashMap

class RegisterActivity : AppCompatActivity() {

    var progressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        supportActionBar?.hide()

        val username        = findViewById<EditText>(R.id.username_register)
        val email           = findViewById<EditText>(R.id.email_register)
        val password        = findViewById<EditText>(R.id.password_register)
        val confirmPassword = findViewById<EditText>(R.id.confirm_password_register)
        val register        = findViewById<Button>(R.id.register_button_register)
        val login           = findViewById<TextView>(R.id.login_button_register)
        progressDialog  = ProgressDialog(this@RegisterActivity)

        btnBackListener()
        txtLoginListener()

        login!!.setOnClickListener {
            val loginIntent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(loginIntent)
        }


        register!!.setOnClickListener {
            val stringUsername          = username!!.text.toString()
            val stringEmail             = email!!.text.toString()
            val stringPassword          = password!!.text.toString()
            val stringConfirmPassword   = confirmPassword!!.text.toString()

            if (stringPassword == stringConfirmPassword && stringPassword != "") {
                createDataToServer(stringUsername, stringEmail, stringPassword)
                Response.Listener { response: String ->
                    try {
                        val jsonObject = JSONObject(response)
                        val resp = jsonObject.getString("server_response")
                        if (resp == "[{\"status\":\"OK\"}]") {
                            Toast.makeText(applicationContext, "Registrasi Berhasil!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(applicationContext, "Registrasi Gagal!", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }

                val loginIntent = Intent(this@RegisterActivity, LoginActivity::class.java)
                startActivity(loginIntent)

            } else {
                Toast.makeText(applicationContext, "Password tidak cocok!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun createDataToServer(username: String, email: String, password: String) {
        if (checkNetworkConnection()) {
            progressDialog!!.show()
            val stringRequest: StringRequest = object : StringRequest(
                Method.POST, DbContract.SERVER_REGISTER_URL,
                Response.Listener { response ->
                    try {
                        val jsonObject = JSONObject(response)
                        val resp = jsonObject.getString("server_response")
                        if (resp == "[{\"status\":\"OK\"}]") {
                            Toast.makeText(applicationContext, "Registrasi Berhasil!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(applicationContext, "Registrasi Gagal!", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }, Response.ErrorListener { }) {
                @Throws(AuthFailureError::class)
                override fun getParams(): Map<String, String>? {
                    val params: MutableMap<String, String> = HashMap()
                    params["username"] = username
                    params["email"] = email
                    params["password"] = password
                    return params
                }
            }
            VolleyConnection.getInstance(this@RegisterActivity).addToRequestQueue(stringRequest)
            Handler().postDelayed({ progressDialog!!.cancel() }, 2000)
        } else {
            Toast.makeText(applicationContext, "Tidak ada koneksi Internet!", Toast.LENGTH_SHORT)
                .show()
        }
    }

    private fun checkNetworkConnection(): Boolean {
        val connectivityManager = this.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }

    private fun btnBackListener() {
        button_back_register.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }
    }

    private fun txtLoginListener() {
        login_button_register.setOnClickListener{
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }
}