package com.dayatrzki.spkpemilihansmartphone

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        btnLoginListener()
        btnRegisterListener()
    }

    private fun btnLoginListener() {
        val btnLoginMain = findViewById<Button>(R.id.login_button_main)
        btnLoginMain.setOnClickListener{
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    private fun btnRegisterListener() {
        val btnSkipMain = findViewById<Button>(R.id.skip_button_main)
        btnSkipMain.setOnClickListener{
            startActivity(Intent(this, HomeActivity::class.java))
        }
    }

}