package com.dayatrzki.spkpemilihansmartphone

import android.annotation.SuppressLint
import android.content.Context
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.Volley
import kotlin.jvm.Synchronized

class VolleyConnection private constructor(context: Context) {
    private var requestQueue: RequestQueue?

    init {
        vCtx = context
        requestQueue = getRequestQueue()
    }

    private fun getRequestQueue(): RequestQueue {
        if (requestQueue == null) {
            requestQueue =
                Volley.newRequestQueue(vCtx.applicationContext)
        }
        return requestQueue as RequestQueue
    }

    fun <T> addToRequestQueue(request: Request<T>?) {
        getRequestQueue().add(request)
    }

    companion object {
        @SuppressLint("StaticFieldLeak")
        private var vInstance: VolleyConnection? = null
        @SuppressLint("StaticFieldLeak")
        private lateinit var vCtx: Context
        @Synchronized
        fun getInstance(context: Context?): VolleyConnection {
            if (vInstance == null) {
                vInstance = context?.let { VolleyConnection(it) }
            }
            return vInstance!!
        }
    }
}