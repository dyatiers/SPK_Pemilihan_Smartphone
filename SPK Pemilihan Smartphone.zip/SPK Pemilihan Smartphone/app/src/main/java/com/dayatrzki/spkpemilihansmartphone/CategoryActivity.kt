package com.dayatrzki.spkpemilihansmartphone

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class CategoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category)
        supportActionBar?.hide()

        val btnHomeCategory = findViewById<Button>(R.id.home_button_category)

        btnHomeCategory.setOnClickListener{
            startActivity(Intent(this, HomeActivity::class.java))
        }

    }
}