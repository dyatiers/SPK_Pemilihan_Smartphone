package com.dayatrzki.spkpemilihansmartphone

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SmartphoneListPostAdapter(private val list: ArrayList<SmartphoneListPostResponse>): RecyclerView.Adapter<SmartphoneListPostAdapter.PostViewHolder> () {
    inner class PostViewHolder(itemView : View): RecyclerView.ViewHolder(itemView) {
        fun bind(smartphoneListPostResponse: SmartphoneListPostResponse) {
            with(itemView) {
                val id_smartphone = "${smartphoneListPostResponse.id_smartphone}"
                val nama_smartphone = "${smartphoneListPostResponse.nama_smartphone}"
                val prosesor = "Chipset : ${smartphoneListPostResponse.prosesor}"
                val ram = "${smartphoneListPostResponse.ram}GB"
                val storage = "${smartphoneListPostResponse.storage}GB"


                val tvID = findViewById<TextView>(R.id.id_smartphone)
                tvID.text = id_smartphone

                val tvSmartphone = findViewById<TextView>(R.id.smartphone_name)
                tvSmartphone.text = nama_smartphone

                val tvProsesor = findViewById<TextView>(R.id.processor_smartphone)
                tvProsesor.text = prosesor

                val tvRAM = findViewById<TextView>(R.id.ram)
                tvRAM.text = ram

                val tvStorage = findViewById<TextView>(R.id.storage)
                tvStorage.text = storage
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_smartphone, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount(): Int =list.size
}