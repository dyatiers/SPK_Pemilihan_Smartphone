package com.dayatrzki.spkpemilihansmartphone

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SmartphoneListActivity : AppCompatActivity() {

    private val list = ArrayList<SmartphoneListPostResponse>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_smartphone_list)
        supportActionBar?.hide()

        val btnHomeSmartphoneList = findViewById<Button>(R.id.home_button_smartphone)

        btnHomeSmartphoneList.setOnClickListener{
            startActivity(Intent(this, HomeActivity::class.java))
        }

        val rvData = findViewById<RecyclerView>(R.id.list_smartphone)
        rvData.setHasFixedSize(true)
        rvData.layoutManager = LinearLayoutManager(this)

        SmartphoneListClient.instance.getPosts().enqueue(object : Callback<ArrayList<SmartphoneListPostResponse>> {
            override fun onResponse(
                call: Call<ArrayList<SmartphoneListPostResponse>>,
                response: Response<ArrayList<SmartphoneListPostResponse>>,
            ) {
                response.body()?.let { list.addAll(it) }
                val adapter = SmartphoneListPostAdapter(list)
                rvData.adapter = adapter
            }

            override fun onFailure(call: Call<ArrayList<SmartphoneListPostResponse>>, t: Throwable) {
                Toast.makeText(applicationContext, "Gagal Terhubung!", Toast.LENGTH_SHORT).show()
            }

        })
    }
}