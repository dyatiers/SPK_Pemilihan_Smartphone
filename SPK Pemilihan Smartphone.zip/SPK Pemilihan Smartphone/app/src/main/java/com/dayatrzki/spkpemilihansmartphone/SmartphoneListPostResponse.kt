package com.dayatrzki.spkpemilihansmartphone

import com.google.gson.annotations.SerializedName

data class SmartphoneListPostResponse(
    @SerializedName("id_smartphone")
    val id_smartphone: String?,
    @SerializedName("nama_smartphone")
    val nama_smartphone: String?,
    @SerializedName("prosesor")
    val prosesor: String?,
    @SerializedName("ram")
    val ram: String?,
    @SerializedName("storage")
    val storage: String?
)
