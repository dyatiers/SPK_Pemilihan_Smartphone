package com.dayatrzki.spkpemilihansmartphone

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_register.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        supportActionBar?.hide()

        btnBackListener()
        txtRegisterListener()
    }

    private fun btnBackListener() {
        button_back_login.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }
    }

    private fun txtRegisterListener() {
        register_button_login.setOnClickListener{
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

}