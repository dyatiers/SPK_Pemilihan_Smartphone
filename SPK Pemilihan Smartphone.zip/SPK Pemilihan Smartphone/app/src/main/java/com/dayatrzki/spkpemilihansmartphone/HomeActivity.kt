package com.dayatrzki.spkpemilihansmartphone

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        supportActionBar?.hide()

        val btnVendorList = findViewById<Button>(R.id.vendor_list_home)
        val btnSmartphoneList = findViewById<Button>(R.id.smartphone_list_home)
        val btnCategory = findViewById<Button>(R.id.smartphone_category_home)

        btnVendorList.setOnClickListener{
            startActivity(Intent(this, VendorListActivity::class.java))
        }

        btnSmartphoneList.setOnClickListener{
            startActivity(Intent(this, SmartphoneListActivity::class.java))
        }

        btnCategory.setOnClickListener{
            startActivity(Intent(this, CategoryActivity::class.java))
        }

    }
}