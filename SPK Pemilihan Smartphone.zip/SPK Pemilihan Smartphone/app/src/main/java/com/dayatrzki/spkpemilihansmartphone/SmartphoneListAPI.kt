package com.dayatrzki.spkpemilihansmartphone

import retrofit2.Call
import retrofit2.http.GET

interface SmartphoneListAPI {
    @GET("get_smartphone.php")
    fun getPosts():Call<ArrayList<SmartphoneListPostResponse>>
}