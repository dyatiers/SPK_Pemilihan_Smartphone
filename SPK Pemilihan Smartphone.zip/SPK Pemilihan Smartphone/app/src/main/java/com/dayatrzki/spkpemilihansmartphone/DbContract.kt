package com.dayatrzki.spkpemilihansmartphone

object DbContract {
    const val SERVER_LOGIN_URL = "http://10.0.2.2/project/spk_smart/check_login.php"
    const val SERVER_REGISTER_URL = "http://10.0.2.2/project/spk_smart/create_register.php"
}